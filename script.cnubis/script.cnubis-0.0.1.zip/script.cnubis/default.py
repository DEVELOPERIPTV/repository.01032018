# -*- coding: utf-8 -*-

import os
import re
import sys
import urllib
import xbmc
import xbmcgui

from lib import playercnubis
from lib import tools


if not os.path.exists(tools.get_userdata()):
    tools.log("cnubis.default Userdata " + tools.get_userdata())
    try:
        os.mkdir(tools.get_userdata())
    except:
        pass


params = sys.argv[1]


def getparams(params):
    tools.log(params)
    params = params.split('&')
    commands = {}
    for param in params:
        split_command = param.split('=')
        key = split_command[0]
        value = split_command[1]
        commands[key] = value

    url = urllib.unquote_plus(commands['url'])
    referer = urllib.unquote_plus(commands['referer'])
    title = commands['title']

    return url, referer, title


url, referer, title = getparams(params)

if (__name__ == "__main__"):
    tools.log("cnubis.default url=" + url)
    dp = xbmcgui.DialogProgress()
    dp.create("Conectando con el addon Cnubis", "Cargando, espere por favor...")

    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0',
               'Referer': referer}

    dp.update(20)
    url = "http://cnubis.com/plugins/mediaplayer/embeder/_embedkodi.php?u=%s" % re.findall(r'u=([A-z0-9]+)', url)[0]
    data = tools.openurl(url, headers=headers)
    video_url = re.findall('file:\s*"([^"]+)"', data, flags=re.DOTALL)[0]

    headers['Referer'] = url
    try:
        url_ad = re.findall('tag:\s*"([^"]+)"', data, flags=re.DOTALL)[0]
        dp.update(40)
        data = tools.openurl(url_ad, headers=headers)

        impre = []
        start = []
        first = []
        middle = []
        third = []
        complete = []
        impre, start, first, middle, third, complete = tools.extract_urls(data, impre, start, first, middle, third,
                                                                          complete)

        url_ad = tools.extract_tag(data, 'vastadtaguri') + "&LR_SUBSEQUENT_VAST2_VPAID_CALL"
        url_ad = url_ad.replace("&LR_SCHEMA=vast2-vpaid", "")

        dp.update(50)
        i = 10
        video_url_ad = ""
        from threading import Thread
        while True:
            try:
                dp.update(50 + i)
                data = tools.openurl(url_ad, headers=headers)
                check_redirect = re.search('<VAST version="2.0">(?:<!--[^-]+-->|)</VAST>', data, flags=re.DOTALL)
                if check_redirect and not "NO_AD" in data:
                    location = tools.openurl(url_ad, headers=headers)
                    data = tools.openurl(url_ad, headers=headers)

                if not "<Wrapper>" in data:
                    if "<InLine>" in data:
                        impre, start, first, middle, third, complete = tools.extract_urls(data, impre, start, first,
                                                                                          middle, third, complete)
                        if "video/mp4" in data or "video/webm" in data or "video/x-flv" in data:
                            video_url_ad = tools.extract_mediafile(data)
                        else:
                            if "<AdParameters>" in data:
                                redirect = re.findall('cs_vurl=([^\]]+)', data, flags=re.DOTALL)[0]
                                data = tools.openurl(redirect, headers=headers)
                                impre, start, first, middle, third, complete = tools.extract_urls(data, impre, start,
                                                                                                  first, middle, third,
                                                                                                  complete)
                                video_url_ad = tools.extract_mediafile(data)
                            else:
                                video_url_ad = tools.extract_url_from_swf(data, headers)
                    else:
                        tools.log("cnubis.default Ningún anuncio disponible")
                    break
                elif "NO_AD" in data:
                    break

                impre, start, first, middle, third, complete = tools.extract_urls(data, impre, start, first, middle,
                                                                                  third, complete)
                url_ad = tools.extract_tag(data, 'vastadtaguri')
                i += 10
            except:
                video_url_ad = ""
                tools.log("cnubis.default Error, no hay ningún anuncio disponible")
                import traceback
                tools.log(traceback.format_exc())
                break
    except:
        video_url_ad = ""
        import traceback
        tools.log(traceback.format_exc())

    if video_url_ad != "":
        listitem = xbmcgui.ListItem(label="Pre-Roll", iconImage="DefaultVideo.png", path=video_url_ad)
        listitem.setInfo("video", {"Title": "Pre-Roll"})
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.add(video_url_ad, listitem)
        listitem = xbmcgui.ListItem(label=title, iconImage="DefaultVideo.png", path=video_url)
        listitem.setInfo("video", {"Title": title})
        playlist.add(video_url, listitem)

        for url_ad in impre:
            t = Thread(target=tools.onlyRequest, kwargs={'url': url_ad, 'headers': headers})
            t.setDaemon(True)
            t.start()
        while True:
            dp.close()
            player = playercnubis.PlayerCnubis(list_complete=complete, headers=headers)
            player.PlayAd(playlist, start, first, middle, third)
            if not player.isPlaying():
                break

    else:
        dp.close()
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        listitem = xbmcgui.ListItem(label=title, iconImage="DefaultVideo.png")
        listitem.setInfo("video", {"Title": title})
        playlist.add(video_url, listitem)
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(playlist)
