# -*- coding: utf-8 -*-
#------------------------------------------------------------
# pelisalacarta - XBMC Plugin
# Canal para seriesdanko_tfm - Testing for Maintenance
# http://blog.tvalacarta.info/plugin-xbmc/pelisalacarta/
#------------------------------------------------------------
from urlparse import urljoin
from re import sub

try: from xbmc import log as info
except: from core.logger import info

from core.scrapertools import *
from core.item import Item

try: from servers.servertools import find_video_items
except: from core.servertools import find_video_items

from core.config import get_library_support

__channel__ = "seriesdanko_tfm"
__category__ = "S, VOS"
__type__ = "generic"
__title__ = "Seriesdanko TfM"
__language__ = "ES"
__date__ = "10/11/2016"
__version__ = "2016101101"

def isGeneric():
    return True

host = "http://seriesdanko.com"

idiomas = {'es':'Español','la':'Latino','vo':'VO','vos':'VOS', 'ca':'Catalán', 'ga':'Gallego', 'ue':'Euskera', 'ba':'Bable'}

def mainlist(item):
    info("[seriesdanko_tfm.py] mainlist")
    return [
        Item(
            channel = __channel__,
            title = title,
            action = action,
            url = url
        )
        for title, action, url
        in [
            ('Novedades','novedades',host),
            ('A-Z','letras',host + '/series.php?id=%s'),
            ('Listado completo','allserieslist',host),
            ('Listado completo con carátulas','series',host + '/series.php?id=listadoConCarátulas'),
            ('Buscar','search',''),
        ]
    ]

def search(item,texto):
    info("[seriesdanko_tfm.py] search")

    item.url = host + "/pag_search.php?q1=" + texto

    try:
        return series(item)

    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error( "%s" % line )
        return []

def novedades(item):
    info("[seriesdanko_tfm.py] novedades")
    return [
        Item(
            channel = __channel__,
            action = "episodios",
            title = title.strip(),
            url = url,
            thumbnail = thumbnail,
            show = sub( r'\s+\d+x\d+[^$]+$|\s+\-[^$]+$|\s+\([^$]+$', '', title.strip() ),
            fulltitle = sub( r'\s+\d+x\d+[^$]+$|\s+\-[^$]+$|\s+\([^$]+$', '', title.strip() )
        )
        for title, url, thumbnail
        in find_multiple_matches(
            datafrom_url(item.url),
            '<a title="([^"]+)" href="([^"]+)".*?src="([^"]+)"'
        )
    ]

def allserieslist(item):
    info("[seriesdanko_tfm.py] allserieslist")
    return [
        Item(
            channel = __channel__,
            action = "episodios",
            title = title.strip(),
            url = url,
            show = title.strip()
        )
        for url, title
        in find_multiple_matches(
            datafrom_url(item.url),
            '<li[^<]+<a href="([^"]+)" title="([^"]+)"[^<]+</a></li>'
        )
    ]

def letras(item):
    info("[seriesdanko_tfm.py] letras")
    return [
        Item(
            channel = __channel__,
            action = "series",
            title = l.replace('#', '0-9'),
            url = item.url % l.replace('#', '0')
        )
        for l
        in "#ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    ]

def series(item):
    info("[seriesdanko_tfm.py] series")
    return sorted(
        [
            Item(
            channel = __channel__,
            action = "episodios",
            title = title.strip(),
            url = url,
            thumbnail = thumbnail,
            show = title.strip()
            )
            for url, title, thumbnail
            in find_multiple_matches(
                datafrom_url(item.url),
                '<div style[^<]+<a href="([^"]+)" title="[^:]+: ([^"]+)".*?src="([^"]+)"[^<]+</a><br>'
            )
        ],
        key=lambda item: item.title
    )

def episodios(item):
    info("[seriesdanko_tfm.py] episodios")

    itemlist = []

    try: data = get_match(
        datafrom_url(item.url),
        '(<div id="T\d+[^>]+>.*?<br><img)'
    )
    except: return [
        Item(channel=__channel__, title="La serie no contiene episodios", action="episodios", url=item.url, folder=False)
    ]

    scrapedplot = sub(
        r'<div align="justify">(.*?)</div>',
        r'\1'.strip(),
        find_single_match(data, '<br><b>.*?</div>(.*?)<br><img')
    ).replace('  ', ' ')

    patron = '<div id="T\d+[^<]+<img src="([^"]+)"(.*?</div>)'
    temporadas_match = re.compile(patron, re.DOTALL).findall(data)

    for scrapedthumbnail, scrapedespisodios in temporadas_match:
        scrapedespisodios = scrapedespisodios.replace('</a><img src=/assets', '</a><idioma/<img src=/assets') \
                                             .replace('width="20" /><br><br>', 'width="20" />/idioma>') \
                                             .replace('</div>', '/idioma>')

        patron = '<a href="([^"]+)">([^<]+)</a><idioma/(.*?)/idioma>'
        episodios_match = re.compile(patron, re.DOTALL).findall(scrapedespisodios)

        for scrapedurl, scrapedtitle, scrapedidioma in episodios_match:
            idiomas_match = re.compile('banderas/([^\.]+)\.png', re.DOTALL).findall(scrapedidioma)
            idioma = " (" + ", ".join([ idiomas[i] for i in idiomas_match ]) + ")"
            title = scrapedtitle + idioma

            itemlist.append( Item(channel=__channel__, action="findvideos", title=title.strip(), url=scrapedurl, thumbnail=scrapedthumbnail, plot=scrapedplot, show=item.show) )

    if get_library_support() and len(itemlist)>0:
        itemlist.append( Item(channel=__channel__, title="Añadir esta serie a la biblioteca de XBMC", url=item.url, action="add_serie_to_library", extra="episodios", show=item.show))
        itemlist.append( Item(channel=__channel__, title="Descargar todos los episodios de la serie", url=item.url, action="download_all_episodes", extra="episodios", show=item.show))

    return itemlist

def findvideos(item):
    info("[seriesdanko_tfm.py] findvideos")
    data = datafrom_url(item.url)
    info("[seriesdanko_tfm.py] findvideos data: %s" % data)
    return [
        Item(
            channel = __channel__,
            action = "play",
            title = opcion + " en " + servidor + " [ " + calidad + " ] [ " + idiomas[idioma] + " ] ( " + fecha + ": " + uploader + " )",
            url = url,
            thumbnail = item.thumbnail,
            plot = item.plot,
            fulltitle = item.fulltitle
        )
        for idioma, fecha, servidor, url, opcion, uploader, calidad
        in find_multiple_matches(
            datafrom_url(item.url)\
            .replace(' online', '') \
            .replace('<td class="tam12"></td></tr>', '<td class="tam12"></td>SD</tr>'),
            '<tr>.*?/banderas/([^\.]+)\.png.*?tam12">([^<]+)<.*?/servidores/([^\.]+)' \
            '\.png.*?href="([^"]+)".*?>([^<]+)<.*?tam12">([^<]+)<.*?tam12">([^<]+)<.*?'
        )
    ]

def play(item):
    info("[seriesdanko_tfm.py] play (url=" + item.url + ", server=" + item.server + ")" )

    data = anti_cloudflare(item.url)
    info("[seriesdanko_tfm.py] play data: %s" % data)
    url = find_single_match(data,'<a href="(http[^<]+)">http[^<]+</a>')
    info("[seriesdanko_tfm.py] play url: %s" % url)

    itemlist = find_video_items( data=url )
    for videoitem in itemlist:
        videoitem.title = item.fulltitle
        videoitem.fulltitle = item.fulltitle
        videoitem.thumbnail = item.thumbnail
        videoitem.channel = __channel__

    return itemlist

def datafrom_url(url):
    info("[seriesdanko_tfm.py] datafrom_url (url=" + url + ")" )
    return decodeHtmlentities(
        sub(
            r'href=" *((?:capitulo|serie|anonim)[^"]+)"',
            'href="' + urljoin( host, r'\1'.strip() ) + '"',
            sub(
                r'>\s+<',
                '><',
                sub(
                    r'<[Bb][Rr] />',
                    ' ',
                    anti_cloudflare(url).replace("'", '"') \
                                        .replace('"""', '"') \
                                        .replace('"../', '"') \
                                        .replace('"/', '"')
                )
            )
        )
    )

def anti_cloudflare(url):

    headers = [
        ['User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0'],
    ]

    try:
        resp_headers = get_headers_from_response(url, headers=headers)
        resp_headers = dict(resp_headers)
    except urllib2.HTTPError, e:
        resp_headers = e.headers

    if 'refresh' in resp_headers:
        time.sleep(int(resp_headers['refresh'][:1]))

        get_headers_from_response(host + "/" + resp_headers['refresh'][7:], headers=headers)

    return cache_page(url, headers=headers)
